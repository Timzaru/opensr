echo "Installing OpenSR on Cloud9 IDE..."
sudo pip install Django==1.5.0
sudo apt-get build-dep python-psycopg2
sudo pip install psycopg2
sudo pip install django-sortedm2m
echo "Finished installation!"